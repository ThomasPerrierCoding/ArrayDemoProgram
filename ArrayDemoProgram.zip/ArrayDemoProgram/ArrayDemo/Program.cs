﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayDemo
{
    class Program
    {

        const int ARRAYSIZE = 10;
        const int MINVAL = 1;
        const int MAXVAL = 100;

        static int[] numArray = new int[ARRAYSIZE];
        static int[] origArray = new int[ARRAYSIZE];
        static Random rnd = new Random();

        static void Main(string[] args)
        {
            fillArray();

            for(; ; )
            {
                presentMenu();
            }
        }
        static void fillArray()
        {
            for (int i = 0; i < numArray.Length; i++)
            {
                origArray[i] = generateRandomNumber();
                numArray[i] = origArray[i];
            }
        }
        static int generateRandomNumber()
        {
            return rnd.Next(1, 101);
        }
        static void presentMenu()
        {
            int menueChoice = 0;

            Console.WriteLine("Enter a 1 to view array in ascending order");
            Console.WriteLine("Enter 2 to view array in descending order");
            Console.WriteLine("Enter a 3 to view contents of a specific array element");
            Console.WriteLine("Enter a 4 to quit the program");
            Console.Write("Enter a 1, 2, 3, or 4 now: ");
            menueChoice = Convert.ToInt16(Console.ReadLine());

            while((menueChoice!=1) && (menueChoice != 2) && (menueChoice != 3) && (menueChoice != 4))
            {
                Console.Clear();
                presentMenu();
            }
            switch(menueChoice)
            {
                case 1:
                    showArrayAsc();
                    break;

                case 2:
                    showArrayDesc();
                    break;

                case 3:
                    showArrayElement();
                    break;

                case 4:
                    Environment.Exit(0);
                    break;

                default:
                    break;
            }
        }
        static void showArrayAsc()
        {
            Array.Sort(numArray);

            Console.WriteLine("Here is the array in ASCENDING ORDER");

            for (int i = 0; i < numArray.Length; i++)
            {
                Console.Write(numArray[i] +"\t");
            }
        }
        static void showArrayDesc()
        {
            Array.Sort(numArray);
            Array.Reverse(numArray);

            Console.WriteLine("Here is the array in DESCENDING ORDER");

            for (int i = 0; i < numArray.Length; i++)
            {
                Console.Write(numArray[i] + "\t");
            }


        }
        static void showArrayElement()
        {
            int elNumber = 0;

            Console.WriteLine("");
        }
    }
}
